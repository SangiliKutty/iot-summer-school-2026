const int ledPin = 9;
const int buttonPin = 2;

int mode = 1;
bool lastButton = HIGH;

void setup() {
  pinMode(ledPin, OUTPUT);
  pinMode(buttonPin, INPUT_PULLUP);
  Serial.begin(9600);
  Serial.println("Mode 1: Slow Breathing");
}

void loop() {
  checkButton();

  switch (mode) {
    case 1:
      slowBreathing();
      break;
    case 2:
      fastPulse();
      break;
    case 3:
      sosPattern();
      break;
  }
}

void checkButton() {
  bool current = digitalRead(buttonPin);

  if (lastButton == HIGH && current == LOW) {
    mode++;
    if (mode > 3) mode = 1;

    switch (mode) {
      case 1:
        Serial.println("Mode 1: Slow Breathing");
        break;
      case 2:
        Serial.println("Mode 2: Fast Pulse");
        break;
      case 3:
        Serial.println("Mode 3: SOS Pattern");
        break;
    }

    delay(200);
  }

  lastButton = current;
}

void slowBreathing() {
  for (int i = 0; i <= 255; i++) {
    analogWrite(ledPin, i);
    delay(6);
    checkButton();
    if (mode != 1) return;
  }

  for (int i = 255; i >= 0; i--) {
    analogWrite(ledPin, i);
    delay(6);
    checkButton();
    if (mode != 1) return;
  }
}

void fastPulse() {
  analogWrite(ledPin, 255);
  delay(250);
  checkButton();
  if (mode != 2) return;

  analogWrite(ledPin, 0);
  delay(250);
  checkButton();
}

void sosPattern() {
  // ...
  for (int i = 0; i < 3; i++) {
    digitalWrite(ledPin, HIGH);
    delay(200);
    digitalWrite(ledPin, LOW);
    delay(200);
    checkButton();
    if (mode != 3) return;
  }

  // ---
  for (int i = 0; i < 3; i++) {
    digitalWrite(ledPin, HIGH);
    delay(600);
    digitalWrite(ledPin, LOW);
    delay(200);
    checkButton();
    if (mode != 3) return;
  }

  // ...
  for (int i = 0; i < 3; i++) {
    digitalWrite(ledPin, HIGH);
    delay(200);
    digitalWrite(ledPin, LOW);
    delay(200);
    checkButton();
    if (mode != 3) return;
  }

  delay(1000);
}